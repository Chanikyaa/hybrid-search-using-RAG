# Data Privacy

Never place API keys, passwords, personal records, or confidential customer content in application logs. Retain only the minimum data required for debugging. Access to production datasets must follow least-privilege rules.
