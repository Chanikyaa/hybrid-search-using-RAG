# Model Evaluation

Every model release must be compared with a documented baseline on a fixed validation dataset. The held-out test set must not be used for repeated tuning. Classification reports should include precision, recall, F1, and a confusion matrix. A release is blocked if its critical-class recall falls below 0.90.
