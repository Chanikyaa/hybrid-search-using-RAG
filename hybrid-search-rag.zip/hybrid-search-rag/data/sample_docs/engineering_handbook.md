# Engineering Handbook

Every service must expose a health endpoint, use bounded timeouts, validate external input, and document a rollback procedure. CI must run unit tests and static checks before a pull request can be merged. Production deployments require a documented rollback owner and a smoke test after release.
