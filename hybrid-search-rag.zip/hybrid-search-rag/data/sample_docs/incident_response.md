# Incident Response

The on-call engineer acknowledges a production incident within fifteen minutes. The incident commander records the timeline, assigns an owner, and posts status updates every thirty minutes. A blameless postmortem is scheduled within two business days after resolution.
