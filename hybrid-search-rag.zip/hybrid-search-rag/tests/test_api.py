from fastapi.testclient import TestClient

from hybrid_rag.api import create_app
from hybrid_rag.config import Settings


def make_client(tmp_path):
    settings = Settings(db_path=tmp_path / "test.sqlite3", chunk_size=300, chunk_overlap=30)
    return TestClient(create_app(settings))


def test_health_and_document_query_flow(tmp_path) -> None:
    client = make_client(tmp_path)
    assert client.get("/health").json()["status"] == "ok"
    text = (
        b"The on-call engineer acknowledges a production incident within fifteen minutes. "
        b"The incident commander records the timeline and assigns an owner."
    )
    response = client.post("/documents?filename=incident.txt", content=text)
    assert response.status_code == 201, response.text
    assert response.json()["chunks_created"] >= 1
    result = client.post("/query", json={"question": "When must an incident be acknowledged?"})
    assert result.status_code == 200
    payload = result.json()
    assert payload["abstained"] is False
    assert "fifteen minutes" in payload["answer"]
    assert "model release" not in payload["answer"].lower()
    assert payload["citations"][0]["filename"] == "incident.txt"


def test_unsupported_file_and_invalid_query(tmp_path) -> None:
    client = make_client(tmp_path)
    response = client.post("/documents?filename=program.exe", content=b"nope")
    assert response.status_code == 422
    assert client.post("/query", json={"question": ""}).status_code == 422


def test_delete_document(tmp_path) -> None:
    client = make_client(tmp_path)
    created = client.post("/documents?filename=delete.txt", content=b"A small document with useful facts.")
    document_id = created.json()["document_id"]
    deleted = client.delete(f"/documents/{document_id}")
    assert deleted.status_code == 200
    assert client.get("/documents").json()["documents"] == []
