from hybrid_rag.embeddings import HashingEmbedder
from hybrid_rag.ingestion import ingest_document
from hybrid_rag.retrieval import bm25_scores, hybrid_search


def corpus():
    embedder = HashingEmbedder()
    docs = [
        ("incident.md", b"The on-call engineer acknowledges a production incident within fifteen minutes."),
        ("privacy.md", b"Never place API keys or passwords in application logs."),
        ("model.md", b"Every model release is compared against a fixed validation baseline."),
    ]
    chunks = []
    for name, content in docs:
        _, doc_chunks = ingest_document(name, content, embedder, 500, 50)
        chunks.extend(doc_chunks)
    return embedder, chunks


def test_bm25_ranks_exact_term_match() -> None:
    _, chunks = corpus()
    scores = bm25_scores("passwords application logs", chunks)
    best = max(range(len(scores)), key=scores.__getitem__)
    assert chunks[best].filename == "privacy.md"


def test_hybrid_search_returns_ranked_hits() -> None:
    embedder, chunks = corpus()
    hits = hybrid_search("production incident acknowledgement", chunks, embedder, top_k=2)
    assert len(hits) == 2
    assert hits[0].score >= hits[1].score
    assert hits[0].dense_rank is not None
    assert hits[0].bm25_rank is not None


def test_empty_query_returns_no_hits() -> None:
    embedder, chunks = corpus()
    assert hybrid_search("  ", chunks, embedder) == []
