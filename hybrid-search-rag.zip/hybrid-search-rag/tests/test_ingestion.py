from hybrid_rag.embeddings import HashingEmbedder
from hybrid_rag.ingestion import extract_pages, ingest_document, split_text


def test_split_text_preserves_content_and_overlaps() -> None:
    text = "alpha beta gamma delta epsilon zeta eta theta"
    chunks = split_text(text, chunk_size=20, overlap=5)
    assert len(chunks) > 1
    assert chunks[0].split()[-1] in chunks[1].split()
    assert "alpha" in chunks[0]
    assert "theta" in chunks[-1]


def test_ingest_text_creates_stable_chunk_metadata() -> None:
    filename = "notes.txt"
    content = b"The retrieval system combines BM25 with dense vector search. Citations identify source passages."
    doc_id, chunks = ingest_document(filename, content, HashingEmbedder(), 40, 5)
    assert doc_id.startswith("notes.txt:")
    assert chunks
    assert all(chunk.filename == filename for chunk in chunks)
    assert all(chunk.embedding for chunk in chunks)
    assert [chunk.chunk_index for chunk in chunks] == list(range(len(chunks)))


def test_unsupported_extension_is_rejected() -> None:
    try:
        extract_pages("payload.exe", b"not a document")
    except ValueError as exc:
        assert "Unsupported file type" in str(exc)
    else:
        raise AssertionError("unsupported extension should fail")


def test_empty_document_is_rejected() -> None:
    try:
        extract_pages("empty.txt", b"")
    except ValueError as exc:
        assert "empty" in str(exc).lower()
    else:
        raise AssertionError("empty document should fail")
