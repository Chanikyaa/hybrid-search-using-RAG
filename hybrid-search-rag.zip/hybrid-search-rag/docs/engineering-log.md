# Engineering Log

## 2026-10-25 — Initial implementation

- Inspected `/openai/project`; no existing portfolio project files were present (the workspace contained only the `cua` directory).
- Created the initial Hybrid Search RAG repository under `/openai/project/hybrid-search-rag`.
- Implemented PDF/Markdown/TXT extraction, chunking, deterministic offline hashing embeddings, optional Sentence Transformers embeddings, BM25, cosine similarity, RRF, SQLite persistence, FastAPI endpoints, and an extractive citation response path.
- Added a synthetic sample document, unit/API tests, Docker files, CI, an evaluation script, and career-readiness notes.
- Verification: `PYTHONPATH=src pytest` passed 10 tests; `compileall` passed; the end-to-end TestClient smoke flow passed for ingestion, answerable query, and unanswerable query. The retrieval evaluation ran on 6 synthetic queries / 4 documents and returned Recall@3 1.000, MRR 0.917, nDCG@3 0.938 for all three retrieval configurations.
- Environment limitations: pip editable install with build isolation could not download build dependencies because network DNS is unavailable; Ruff and Docker are not installed, so lint and container build remain unverified.
- Known limitations: no OCR, no generative LLM answerer, no authentication/tenant isolation/rate limiting, and the hashing embedding backend is lexical rather than semantic.

## Next steps

1. Run pytest and Ruff; fix all failures and rerun.
2. Run the evaluation script and record actual baseline results.
3. Add answer/citation evaluation and calibrated abstention cases.
4. Review Docker build and end-to-end API workflow.
