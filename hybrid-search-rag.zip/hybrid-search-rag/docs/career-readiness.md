# Career Readiness — Hybrid Search RAG

## Target roles

- Generative AI Engineer / Applied AI Engineer
- Machine Learning Engineer
- NLP Engineer
- AI Engineer
- MLOps Engineer (supporting evidence: packaging, tests, CI, Docker; expand monitoring before emphasizing MLOps)

## Skills demonstrated by this implementation

| Job requirement | Evidence in repository | Status |
|---|---|---|
| Python application design | `src/hybrid_rag/` modules and typed domain models | Implemented; review style checks |
| Document ingestion | PDF, Markdown, TXT extraction and chunking | Implemented; OCR not included |
| Retrieval systems | BM25, cosine similarity, RRF | Implemented; benchmark still to run |
| Embeddings | Offline hashing backend; optional Sentence Transformers backend | Implemented; semantic backend needs optional install/model run |
| API development | FastAPI, Pydantic validation, OpenAPI | Implemented; no auth yet |
| Data persistence | SQLite documents and chunk vectors | Implemented; small corpus only |
| Evaluation | Retrieval metrics and fixed synthetic examples | Starter evaluator; expand labeled set |
| Testing and CI | Unit/API tests and GitHub Actions | Implemented; confirm CI execution after push |
| Production security | Upload limits, path checks, explicit limitations | Partial; no authentication or rate limiting |

## Resume bullet templates

Replace every bracketed placeholder with verified results from your own run.

1. Built a local-first document QA API supporting PDF/Markdown/TXT ingestion, chunk metadata, SQLite persistence, BM25 and vector retrieval, and citation-backed extractive answers; evaluated on **[N]** labeled queries with **[Recall@5/MRR/nDCG@5]** of **[measured value]**.
2. Implemented reciprocal-rank fusion to combine lexical and vector rankings; measured **[metric]** change of **[value]** against BM25-only and dense-only baselines on a fixed evaluation set.
3. Added FastAPI endpoints, input validation, automated tests, Docker packaging, and CI; verified **[number]** tests and documented security limitations including lack of authentication and OCR.

## Results to measure

- Recall@1/3/5, MRR, and nDCG@5 for BM25-only, dense-only, and hybrid retrieval.
- Correct citation rate and answer support rate on a manually labeled set.
- Abstention precision/recall for unanswerable questions.
- Ingestion time, query latency (median and p95), memory use, and database size.
- Test count and CI status after running the checks.

## Five-minute demo script

1. (0:00–0:45) Explain the problem: a user needs evidence-backed answers from local documents.
2. (0:45–1:30) Show ingestion of `data/sample_docs/engineering_handbook.md` and inspect document/chunk metadata.
3. (1:30–2:30) Ask a supported question; open the cited chunk and verify the statement.
4. (2:30–3:15) Ask a question absent from the corpus and demonstrate abstention.
5. (3:15–4:15) Explain BM25, vector similarity, and RRF; compare baseline metrics from the evaluation script.
6. (4:15–5:00) Show tests, CI, security limitations, and the next improvement you would implement.

## Two-minute architecture explanation

A FastAPI layer validates document and query requests. Ingestion extracts page-aware text from PDFs or reads UTF-8 text files, then splits it into overlapping chunks. Each chunk is stored in SQLite with metadata and an embedding vector. At query time, the system computes BM25 lexical scores and cosine similarity scores, ranks each result list, and fuses the ranks with reciprocal-rank fusion. The current answer layer selects sentences from retrieved passages and attaches chunk-level citations; it does not call a generative model. This keeps the behavior inspectable while leaving room to compare a semantic embedding model and a grounded generation layer later.

## Interview questions and model answers

1. **What problem does RAG solve?** It retrieves external evidence at inference time so answers can use a changeable corpus rather than relying only on model parameters. This version implements retrieval and extractive answering, not an LLM generator.
2. **Why hybrid retrieval?** BM25 is strong for exact terms and identifiers; dense retrieval can help with paraphrases. Their complementary rankings can improve recall, but only evaluation can show whether fusion helps this dataset.
3. **How does BM25 work?** It scores query-term matches using term frequency, inverse document frequency, and document-length normalization.
4. **What is cosine similarity?** The dot product of two vectors divided by their norms; it compares vector direction rather than raw magnitude.
5. **What is reciprocal-rank fusion?** It adds `1 / (k + rank)` from each ranked list. It combines ranks without requiring scores from different retrievers to be calibrated to the same scale.
6. **Why chunk documents?** Retrieval over smaller passages gives more targeted evidence and supports citations, at the cost of possible loss of context across boundaries.
7. **Why overlap chunks?** It reduces the chance that a fact split at a boundary becomes unretrievable; excessive overlap increases index size and duplicated evidence.
8. **Why store page metadata?** It allows users to trace a result to its original PDF page. Non-PDF text files have no page number in this implementation.
9. **Is the default embedding model semantic?** No. HashingEmbedder creates deterministic hashed lexical feature vectors. SentenceTransformerEmbedder is the optional semantic backend.
10. **What does RRF k control?** It smooths rank contributions; larger values reduce the relative difference between top and lower ranks.
11. **How do you evaluate retrieval?** Use labeled query-to-relevant-chunk judgments and report Recall@k, MRR, and nDCG@k on a fixed dataset.
12. **What is Recall@k?** The fraction of queries for which at least one relevant item appears in the top k, or a defined relevant-item recall variant when multiple relevant chunks are labeled. The evaluator must state which definition it uses.
13. **What is MRR?** The mean reciprocal rank of the first relevant result; it rewards retrieving a relevant passage early.
14. **What is nDCG?** A rank-sensitive metric that supports graded relevance and normalizes discounted cumulative gain by an ideal ranking.
15. **How does the system avoid hallucination?** The current answer layer selects source sentences rather than generating novel text. It can still select incomplete or misleading sentences, so citations and evaluation remain necessary.
16. **What happens if the evidence is missing?** The system abstains when retrieval has no usable lexical/vector signal or no candidate sentence overlaps query terms. This heuristic needs calibration on labeled unanswerable questions.
17. **Why SQLite instead of a vector database?** It simplifies local setup and is adequate for a small corpus. Loading every chunk for each query does not scale; a vector index/database becomes useful as corpus size and filtering needs grow.
18. **How are updates handled?** A re-ingested filename replaces the existing document and its chunks. Document IDs include a content hash so content versions are distinguishable.
19. **What are the security gaps?** No authentication, tenant isolation, or rate limiting. Localhost binding and upload limits reduce accidental exposure but do not make it production-secure.
20. **How would you add generated answers?** Introduce a provider interface that receives only selected evidence, requires structured citation references, validates citations against retrieved chunks, and abstains when support is insufficient. Evaluate groundedness separately from fluency.

## Debugging / system-design scenarios

1. **Exact keyword queries work, paraphrases fail.** Verify which embedding backend is configured; the hashing backend is lexical. Install the semantic extra, benchmark it, and compare dense-only and hybrid retrieval.
2. **A relevant document is indexed but not retrieved.** Inspect extraction output, chunk boundaries, tokenization, and per-retriever ranks before changing fusion parameters.
3. **Answers cite the wrong passage.** Reproduce the query, inspect candidate sentences and citation-to-chunk mapping, then add a regression test and labeled citation judgments.
4. **Latency rises with corpus size.** Profile extraction versus query-time scoring. The current implementation loads all chunks and scans them; measure before adopting an ANN index or separate vector database.
5. **A customer can access another customer's documents.** The current prototype has no tenant authorization and must not be deployed in that state. Add authenticated identity, tenant-scoped database queries, and cross-tenant isolation tests before exposure.

## Likely interviewer objections

- **“This isn't full generative RAG.”** Correct: this first version deliberately focuses on ingestion, hybrid retrieval, citations, and an extractive answer baseline. A grounded LLM answerer is a documented future milestone.
- **“The default embeddings aren't semantic.”** Correct. The default is offline deterministic hashing. Semantic retrieval is an optional backend and must be evaluated separately.
- **“Where are your benchmark numbers?”** Do not quote any until the evaluation script has been run on a fixed labeled set. The starter synthetic corpus is only a pipeline smoke test.
- **“Would you deploy this publicly?”** Not as-is. It lacks authentication, tenant isolation, rate limiting, and operational controls.
