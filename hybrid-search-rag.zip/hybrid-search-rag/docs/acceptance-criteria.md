# Acceptance Criteria — First Working Version

A criterion is accepted only after its verification command or test has been run and its outcome recorded.

- [x] Accept PDF, Markdown, and UTF-8 TXT documents; reject unsupported extensions and empty input.
- [x] Extract PDF text with page references; explicitly reject PDFs without extractable text.
- [x] Chunk text with configurable size and overlap and retain source metadata.
- [x] Persist document metadata, chunks, and vectors in SQLite.
- [x] Replace an existing document with the same filename and support document deletion.
- [x] Compute BM25 and cosine-based rankings and fuse ranks with RRF.
- [x] Expose health, ingestion, listing, deletion, and query endpoints.
- [x] Return citations pointing to retrieved source chunks and abstain when no evidence sentence is identified.
- [x] Provide an offline mode that does not require API keys or model downloads.
- [x] Provide a browser demo, Docker configuration, CI workflow, and setup documentation.
- [x] Run automated unit/API tests and an end-to-end API smoke test in the current environment.
- [ ] Run Ruff and address all lint findings (Ruff is not installed in this offline environment).
- [ ] Build and run the Docker image (not verified in this environment).
- [ ] Evaluate semantic embeddings separately using the optional backend (model dependency unavailable in this environment).
- [ ] Expand the labeled evaluation set and include answer correctness, groundedness, citation support, and calibrated abstention.
- [ ] Add authentication, authorization, rate limiting, and tenant isolation before any public deployment.

The checked items above describe implemented or executed work in the local workspace; unchecked items are not claimed complete.
