"""Typed domain models shared by retrieval, persistence, and the API."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Chunk:
    chunk_id: str
    document_id: str
    filename: str
    text: str
    page: int | None
    chunk_index: int
    embedding: list[float]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class SearchHit:
    chunk: Chunk
    score: float
    dense_score: float
    bm25_score: float
    dense_rank: int | None
    bm25_rank: int | None


@dataclass(frozen=True, slots=True)
class Answer:
    question: str
    answer: str
    abstained: bool
    citations: list[dict[str, Any]]
    retrieval: list[dict[str, Any]]
