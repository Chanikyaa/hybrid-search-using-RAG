"""BM25, cosine similarity, and reciprocal-rank-fusion retrieval."""

from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Sequence

import numpy as np

from hybrid_rag.embeddings import Embedder
from hybrid_rag.models import Chunk, SearchHit

TOKEN_RE = re.compile(r"[\w'-]+", re.UNICODE)


def tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(text.lower())


def cosine(left: Sequence[float], right: Sequence[float]) -> float:
    a = np.asarray(left, dtype=np.float32)
    b = np.asarray(right, dtype=np.float32)
    denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float(np.dot(a, b) / denominator) if denominator else 0.0


def bm25_scores(query: str, chunks: Sequence[Chunk], k1: float = 1.5, b: float = 0.75) -> list[float]:
    """Compute BM25 scores over the supplied chunk corpus."""
    if not chunks:
        return []
    tokenized = [tokenize(chunk.text) for chunk in chunks]
    query_terms = set(tokenize(query))
    if not query_terms:
        return [0.0] * len(chunks)
    doc_lengths = [len(tokens) for tokens in tokenized]
    avg_length = sum(doc_lengths) / len(doc_lengths) if doc_lengths else 0.0
    document_frequency: Counter[str] = Counter()
    frequencies = [Counter(tokens) for tokens in tokenized]
    for counts in frequencies:
        document_frequency.update(counts.keys())
    scores: list[float] = []
    total_docs = len(chunks)
    for counts, length in zip(frequencies, doc_lengths, strict=True):
        score = 0.0
        for term in query_terms:
            tf = counts.get(term, 0)
            if not tf:
                continue
            df = document_frequency[term]
            inverse = math.log(1 + (total_docs - df + 0.5) / (df + 0.5))
            norm = tf + k1 * (1 - b + b * length / avg_length) if avg_length else tf + k1
            score += inverse * (tf * (k1 + 1) / norm)
        scores.append(score)
    return scores


def hybrid_search(
    query: str,
    chunks: Sequence[Chunk],
    embedder: Embedder,
    top_k: int = 5,
    rrf_k: int = 60,
) -> list[SearchHit]:
    if not chunks or not tokenize(query):
        return []
    query_vector = embedder.encode([query])[0]
    dense_scores = [cosine(query_vector, chunk.embedding) for chunk in chunks]
    lexical_scores = bm25_scores(query, chunks)
    dense_order = sorted(range(len(chunks)), key=lambda i: dense_scores[i], reverse=True)
    lexical_order = sorted(range(len(chunks)), key=lambda i: lexical_scores[i], reverse=True)
    dense_rank = {index: rank for rank, index in enumerate(dense_order, start=1)}
    lexical_rank = {index: rank for rank, index in enumerate(lexical_order, start=1)}
    fused = {
        index: 1.0 / (rrf_k + dense_rank[index]) + 1.0 / (rrf_k + lexical_rank[index])
        for index in range(len(chunks))
    }
    ordered = sorted(fused, key=fused.get, reverse=True)[:top_k]
    return [
        SearchHit(
            chunk=chunks[index],
            score=fused[index],
            dense_score=dense_scores[index],
            bm25_score=lexical_scores[index],
            dense_rank=dense_rank[index],
            bm25_rank=lexical_rank[index],
        )
        for index in ordered
    ]
