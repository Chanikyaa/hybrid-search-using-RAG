"""Application service for ingestion, retrieval, and evidence-based responses."""

from __future__ import annotations

import re
from collections.abc import Sequence

from hybrid_rag.config import Settings
from hybrid_rag.embeddings import Embedder
from hybrid_rag.ingestion import ingest_document
from hybrid_rag.models import Answer, Chunk, SearchHit
from hybrid_rag.retrieval import hybrid_search
from hybrid_rag.store import SQLiteStore

SENTENCE_RE = re.compile(r"(?<=[.!?])\s+|(?=\s*#{1,6}\s+)")
STOPWORDS = {"a", "an", "and", "are", "be", "can", "do", "does", "for", "how", "in", "is", "it", "must", "of", "on", "or", "should", "the", "to", "what", "when", "where", "which", "who", "why", "with"}


def _terms(text: str) -> set[str]:
    terms = set(re.findall(r"[\w'-]+", text.lower())) - STOPWORDS
    normalized: set[str] = set()
    for term in terms:
        if len(term) > 5 and term.endswith("ing"):
            term = term[:-3]
        elif len(term) > 4 and term.endswith("ed"):
            term = term[:-2]
        elif len(term) > 4 and term.endswith("es"):
            term = term[:-2]
        elif len(term) > 3 and term.endswith("s"):
            term = term[:-1]
        normalized.add(term)
    return normalized


class RAGService:
    def __init__(self, settings: Settings, store: SQLiteStore, embedder: Embedder) -> None:
        self.settings = settings
        self.store = store
        self.embedder = embedder

    def ingest(self, filename: str, content: bytes) -> dict[str, object]:
        doc_id, chunks = ingest_document(
            filename, content, self.embedder, self.settings.chunk_size, self.settings.chunk_overlap
        )
        self.store.replace_document(doc_id, filename, chunks)
        return {"document_id": doc_id, "filename": filename, "chunks_created": len(chunks)}

    def search(self, query: str, top_k: int | None = None) -> list[SearchHit]:
        return hybrid_search(
            query,
            self.store.all_chunks(),
            self.embedder,
            top_k=top_k or self.settings.top_k,
            rrf_k=self.settings.rrf_k,
        )

    def answer(self, question: str, top_k: int | None = None) -> Answer:
        hits = self.search(question, top_k)
        if not hits:
            return Answer(question, "I don't have enough evidence in the indexed documents to answer that.", True, [], [])
        # The demo answerer is deliberately extractive: it selects evidence sentences and does not
        # invent a generative response. A provider-backed answerer can be added behind this boundary.
        best_score = max(hit.dense_score for hit in hits)
        best_bm25 = max(hit.bm25_score for hit in hits)
        if best_score <= 0.0 and best_bm25 <= 0.0:
            return Answer(question, "I don't have enough evidence in the indexed documents to answer that.", True, [], [])
        query_terms = _terms(question)
        candidates: list[tuple[int, float, SearchHit, str]] = []
        for hit in hits:
            for sentence in SENTENCE_RE.split(hit.chunk.text):
                sentence = sentence.strip()
                if not sentence:
                    continue
                sentence = re.sub(r"^\s*#{1,6}\s+", "", sentence).strip()
                terms = _terms(sentence)
                if len(terms) < 3:
                    continue
                overlap_count = len(query_terms & terms)
                overlap = overlap_count / max(1, len(query_terms))
                minimum_overlap = min(2, len(query_terms))
                if overlap_count >= minimum_overlap:
                    candidates.append((overlap_count, hit.score + overlap, hit, sentence))
        if not candidates:
            return Answer(question, "I don't have enough evidence in the indexed documents to answer that.", True, [], [])
        candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
        selected: list[tuple[SearchHit, str]] = []
        seen: set[str] = set()
        for _, _, hit, sentence in candidates:
            normalized_sentence = sentence.casefold()
            if normalized_sentence not in seen:
                selected.append((hit, sentence))
                seen.add(normalized_sentence)
            if len(selected) == 2:
                break
        citations: list[dict[str, object]] = []
        citation_ids: dict[str, int] = {}
        answer_lines: list[str] = []
        for hit, sentence in selected:
            chunk_id = hit.chunk.chunk_id
            if chunk_id not in citation_ids:
                citation_ids[chunk_id] = len(citations) + 1
                citations.append(
                    {
                        "citation_id": citation_ids[chunk_id],
                        "filename": hit.chunk.filename,
                        "page": hit.chunk.page,
                        "chunk_id": chunk_id,
                        "excerpt": hit.chunk.text,
                    }
                )
            answer_lines.append(f"{sentence} [{citation_ids[chunk_id]}]")
        retrieval = [
            {
                "chunk_id": hit.chunk.chunk_id,
                "filename": hit.chunk.filename,
                "page": hit.chunk.page,
                "score": round(hit.score, 6),
                "dense_score": round(hit.dense_score, 6),
                "bm25_score": round(hit.bm25_score, 6),
            }
            for hit in hits
        ]
        return Answer(question, " ".join(answer_lines), False, citations, retrieval)

    def documents(self) -> Sequence[dict[str, object]]:
        return self.store.list_documents()
