"""FastAPI entry point and minimal browser UI."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from hybrid_rag.config import Settings
from hybrid_rag.embeddings import make_embedder
from hybrid_rag.service import RAGService
from hybrid_rag.store import SQLiteStore

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger(__name__)
MAX_UPLOAD_BYTES = 10 * 1024 * 1024


class QueryRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)
    top_k: int = Field(default=5, ge=1, le=20)


def create_app(settings: Settings | None = None) -> FastAPI:
    configured = settings or Settings()
    configured.validate()
    store = SQLiteStore(configured.db_path)
    embedder = make_embedder(configured.embedding_backend, configured.embedding_model)
    service = RAGService(configured, store, embedder)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        logger.info("Hybrid RAG API started; embedding_backend=%s", configured.embedding_backend)
        yield
        logger.info("Hybrid RAG API stopped")

    app = FastAPI(
        title="Hybrid Search RAG API",
        version="0.1.0",
        description="Local-first document ingestion, hybrid retrieval, and citation-grounded extractive answers.",
        lifespan=lifespan,
    )
    app.state.rag_service = service

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "embedding_backend": configured.embedding_backend}

    @app.get("/documents")
    def list_documents() -> dict[str, object]:
        return {"documents": service.documents()}

    @app.post("/documents", status_code=201)
    async def upload_document(
        request: Request,
        filename: Annotated[str, Query(min_length=1, max_length=255)],
    ) -> dict[str, object]:
        if Path(filename).name != filename or filename in {".", ".."}:
            raise HTTPException(status_code=400, detail="filename must be a simple filename, not a path")
        content = await request.body()
        if len(content) > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413, detail="Upload exceeds the 10 MiB limit")
        try:
            result = service.ingest(filename, content)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        logger.info("Document ingested filename=%s chunks=%s", filename, result["chunks_created"])
        return result

    @app.delete("/documents/{document_id}")
    def delete_document(document_id: str) -> dict[str, object]:
        deleted = store.delete_document(document_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="Document not found")
        return {"deleted": True, "document_id": document_id}

    @app.post("/query")
    def query_documents(payload: QueryRequest) -> dict[str, object]:
        result = service.answer(payload.question, payload.top_k)
        return {
            "question": result.question,
            "answer": result.answer,
            "abstained": result.abstained,
            "citations": result.citations,
            "retrieval": result.retrieval,
        }

    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    def home() -> str:
        return """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hybrid Search RAG</title><style>
body{font:16px system-ui;max-width:850px;margin:3rem auto;padding:0 1rem;color:#202124}
textarea,input,button{font:inherit;padding:.65rem;border:1px solid #aaa;border-radius:6px}textarea{width:100%;min-height:100px;box-sizing:border-box}button{cursor:pointer;background:#202124;color:white;margin:.5rem 0}
section{margin:1.5rem 0;padding:1rem;border:1px solid #ddd;border-radius:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f5f5;padding:1rem;border-radius:6px}
small{color:#555}</style></head><body><h1>Hybrid Search RAG</h1>
<p>Upload a PDF, Markdown, or TXT document, then ask a question. Answers are extractive and cite source chunks.</p>
<section><h2>1. Add a document</h2><input id="file" type="file" accept=".pdf,.md,.txt"><br><button onclick="upload()">Index document</button><pre id="upload-result">No document uploaded yet.</pre></section>
<section><h2>2. Ask a question</h2><textarea id="question" placeholder="Ask something supported by your indexed documents..."></textarea><br><button onclick="ask()">Search and answer</button><pre id="answer">Your answer and citations will appear here.</pre></section>
<section><h2>Indexed documents</h2><button onclick="listDocs()">Refresh list</button><pre id="documents">No list loaded.</pre></section>
<small>Offline hashing embeddings are lexical rather than semantic. See the README for the semantic embedding option and limitations.</small>
<script>
async function upload(){const f=document.getElementById('file').files[0];if(!f){alert('Choose a file first.');return}const r=await fetch('/documents?filename='+encodeURIComponent(f.name),{method:'POST',body:f});document.getElementById('upload-result').textContent=JSON.stringify(await r.json(),null,2);if(r.ok)listDocs()}
async function ask(){const question=document.getElementById('question').value;const r=await fetch('/query',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question})});document.getElementById('answer').textContent=JSON.stringify(await r.json(),null,2)}
async function listDocs(){const r=await fetch('/documents');document.getElementById('documents').textContent=JSON.stringify(await r.json(),null,2)}
</script></body></html>"""

    return app


app = create_app()
