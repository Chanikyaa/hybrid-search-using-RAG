"""Document extraction and deterministic overlapping chunking."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

from pypdf import PdfReader

from hybrid_rag.embeddings import Embedder
from hybrid_rag.models import Chunk

SUPPORTED_EXTENSIONS = {".pdf", ".md", ".txt"}


def document_id(filename: str, content: bytes) -> str:
    digest = hashlib.sha256(content).hexdigest()[:16]
    return f"{Path(filename).name}:{digest}"


def extract_pages(filename: str, content: bytes) -> list[tuple[int | None, str]]:
    suffix = Path(filename).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type '{suffix}'. Supported: PDF, Markdown, TXT.")
    if not content:
        raise ValueError("The uploaded document is empty.")
    if suffix == ".pdf":
        import io

        try:
            reader = PdfReader(io.BytesIO(content), strict=True)
            pages = [(index + 1, page.extract_text() or "") for index, page in enumerate(reader.pages)]
        except Exception as exc:
            raise ValueError("Could not parse this PDF. It may be malformed or encrypted.") from exc
        if not any(text.strip() for _, text in pages):
            raise ValueError("No extractable text found in PDF; OCR is not implemented in this version.")
        return pages
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("Text files must be UTF-8 encoded.") from exc
    return [(None, text)]


def split_text(text: str, chunk_size: int, overlap: int) -> list[str]:
    without_headings = re.sub(r"(?m)^\s*#{1,6}\s+.*$", "", text)
    normalized = re.sub(r"\s+", " ", without_headings).strip()
    if not normalized:
        return []
    chunks: list[str] = []
    start = 0
    while start < len(normalized):
        end = min(start + chunk_size, len(normalized))
        if end < len(normalized):
            boundary = normalized.rfind(" ", start + chunk_size // 2, end)
            if boundary > start:
                end = boundary
        piece = normalized[start:end].strip()
        if piece:
            chunks.append(piece)
        if end >= len(normalized):
            break
        start = max(end - overlap, start + 1)
    return chunks


def ingest_document(
    filename: str,
    content: bytes,
    embedder: Embedder,
    chunk_size: int,
    chunk_overlap: int,
) -> tuple[str, list[Chunk]]:
    pages = extract_pages(filename, content)
    doc_id = document_id(filename, content)
    records: list[tuple[int | None, str]] = []
    for page, text in pages:
        records.extend((page, piece) for piece in split_text(text, chunk_size, chunk_overlap))
    if not records:
        raise ValueError("The document contains no extractable text.")
    vectors = embedder.encode([text for _, text in records])
    chunks = [
        Chunk(
            chunk_id=f"{doc_id}#chunk-{index}",
            document_id=doc_id,
            filename=Path(filename).name,
            text=text,
            page=page,
            chunk_index=index,
            embedding=vectors[index],
        )
        for index, (page, text) in enumerate(records)
    ]
    return doc_id, chunks
