"""Local-first hybrid retrieval and grounded document question answering."""

__version__ = "0.1.0"
