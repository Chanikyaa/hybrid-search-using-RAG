"""Embedding backends. The default hashed backend is offline and not semantic."""

from __future__ import annotations

import hashlib
import math
import re
from collections.abc import Sequence
from typing import Protocol

TOKEN_RE = re.compile(r"[\w'-]+", re.UNICODE)


class Embedder(Protocol):
    def encode(self, texts: Sequence[str]) -> list[list[float]]: ...


def _normalize(vector: list[float]) -> list[float]:
    norm = math.sqrt(sum(value * value for value in vector))
    return [value / norm for value in vector] if norm else vector


class HashingEmbedder:
    """Stable feature-hashed token vectors for deterministic, offline smoke tests.

    This is a dense representation of lexical features, not a semantic language embedding.
    Use SentenceTransformerEmbedder for semantic similarity experiments.
    """

    def __init__(self, dimensions: int = 384) -> None:
        self.dimensions = dimensions

    def encode(self, texts: Sequence[str]) -> list[list[float]]:
        vectors: list[list[float]] = []
        for text in texts:
            vector = [0.0] * self.dimensions
            for token in TOKEN_RE.findall(text.lower()):
                digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
                index = int.from_bytes(digest, "big") % self.dimensions
                sign = 1.0 if digest[0] & 1 else -1.0
                vector[index] += sign
            vectors.append(_normalize(vector))
        return vectors


class SentenceTransformerEmbedder:
    """Optional semantic embeddings, loaded only when explicitly configured."""

    def __init__(self, model_name: str) -> None:
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "Semantic embeddings require the optional dependency. Install with "
                "`pip install -e '.[semantic]'`."
            ) from exc
        self._model = SentenceTransformer(model_name)

    def encode(self, texts: Sequence[str]) -> list[list[float]]:
        matrix = self._model.encode(list(texts), normalize_embeddings=True)
        return [[float(value) for value in row] for row in matrix.tolist()]


def make_embedder(backend: str, model_name: str) -> Embedder:
    if backend == "hashing":
        return HashingEmbedder()
    if backend == "sentence-transformers":
        return SentenceTransformerEmbedder(model_name)
    raise ValueError(f"Unsupported embedding backend: {backend}")
