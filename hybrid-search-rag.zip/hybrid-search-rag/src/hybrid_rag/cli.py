"""Small CLI for indexing files without using the browser or API."""

from __future__ import annotations

import argparse

from hybrid_rag.api import create_app
from hybrid_rag.config import Settings
from hybrid_rag.embeddings import make_embedder
from hybrid_rag.service import RAGService
from hybrid_rag.store import SQLiteStore


def main() -> None:
    parser = argparse.ArgumentParser(description="Index and query local documents using hybrid RAG")
    parser.add_argument("command", choices=["serve", "ingest", "query", "documents"])
    parser.add_argument("value", nargs="?", help="file path for ingest or question for query")
    args = parser.parse_args()
    settings = Settings()
    settings.validate()
    if args.command == "serve":
        import uvicorn

        uvicorn.run(create_app(settings), host="127.0.0.1", port=8000)
        return
    service = RAGService(settings, SQLiteStore(settings.db_path), make_embedder(settings.embedding_backend, settings.embedding_model))
    if args.command == "ingest":
        if not args.value:
            parser.error("ingest requires a file path")
        from pathlib import Path

        path = Path(args.value)
        print(service.ingest(path.name, path.read_bytes()))
    elif args.command == "query":
        if not args.value:
            parser.error("query requires a question")
        result = service.answer(args.value)
        print(result.answer)
        for citation in result.citations:
            print(f"[{citation['citation_id']}] {citation['filename']} page={citation['page']}")
    else:
        for document in service.documents():
            print(document)


if __name__ == "__main__":
    main()
