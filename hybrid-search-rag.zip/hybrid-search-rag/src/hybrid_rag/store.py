"""Small SQLite persistence layer; no external database service is required."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from hybrid_rag.models import Chunk


class SQLiteStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        if str(path) != ":memory:":
            path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(str(self.path), timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS documents (
                    document_id TEXT PRIMARY KEY,
                    filename TEXT NOT NULL,
                    chunk_count INTEGER NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS chunks (
                    chunk_id TEXT PRIMARY KEY,
                    document_id TEXT NOT NULL REFERENCES documents(document_id) ON DELETE CASCADE,
                    filename TEXT NOT NULL,
                    text TEXT NOT NULL,
                    page INTEGER,
                    chunk_index INTEGER NOT NULL,
                    embedding_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_chunks_document_id ON chunks(document_id);
                """
            )

    def replace_document(self, document_id: str, filename: str, chunks: list[Chunk]) -> None:
        with self._connect() as connection:
            connection.execute("DELETE FROM documents WHERE filename = ?", (filename,))
            connection.execute(
                "INSERT OR REPLACE INTO documents(document_id, filename, chunk_count) VALUES (?, ?, ?)",
                (document_id, filename, len(chunks)),
            )
            connection.executemany(
                """INSERT OR REPLACE INTO chunks
                (chunk_id, document_id, filename, text, page, chunk_index, embedding_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                [
                    (
                        chunk.chunk_id,
                        chunk.document_id,
                        chunk.filename,
                        chunk.text,
                        chunk.page,
                        chunk.chunk_index,
                        json.dumps(chunk.embedding),
                    )
                    for chunk in chunks
                ],
            )

    def all_chunks(self) -> list[Chunk]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT chunk_id, document_id, filename, text, page, chunk_index, embedding_json "
                "FROM chunks ORDER BY filename, chunk_index"
            ).fetchall()
        return [
            Chunk(
                chunk_id=row["chunk_id"],
                document_id=row["document_id"],
                filename=row["filename"],
                text=row["text"],
                page=row["page"],
                chunk_index=row["chunk_index"],
                embedding=json.loads(row["embedding_json"]),
            )
            for row in rows
        ]

    def list_documents(self) -> list[dict[str, object]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT document_id, filename, chunk_count, created_at FROM documents ORDER BY filename"
            ).fetchall()
        return [dict(row) for row in rows]

    def delete_document(self, document_id: str) -> bool:
        with self._connect() as connection:
            cursor = connection.execute("DELETE FROM documents WHERE document_id = ?", (document_id,))
            return cursor.rowcount > 0
