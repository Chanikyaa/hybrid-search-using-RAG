"""Environment-based application configuration."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Settings:
    db_path: Path = Path(os.getenv("RAG_DB_PATH", "./data/rag.sqlite3"))
    embedding_backend: str = os.getenv("RAG_EMBEDDING_BACKEND", "hashing").lower()
    embedding_model: str = os.getenv(
        "RAG_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
    )
    chunk_size: int = int(os.getenv("RAG_CHUNK_SIZE", "900"))
    chunk_overlap: int = int(os.getenv("RAG_CHUNK_OVERLAP", "150"))
    top_k: int = int(os.getenv("RAG_TOP_K", "5"))
    rrf_k: int = int(os.getenv("RAG_RRF_K", "60"))

    def validate(self) -> None:
        if self.embedding_backend not in {"hashing", "sentence-transformers"}:
            raise ValueError("RAG_EMBEDDING_BACKEND must be 'hashing' or 'sentence-transformers'.")
        if self.chunk_size < 1:
            raise ValueError("RAG_CHUNK_SIZE must be positive.")
        if not 0 <= self.chunk_overlap < self.chunk_size:
            raise ValueError("RAG_CHUNK_OVERLAP must be non-negative and smaller than chunk size.")
        if self.top_k < 1 or self.rrf_k < 1:
            raise ValueError("RAG_TOP_K and RAG_RRF_K must be positive.")
