"""Compare BM25-only, dense-only, and hybrid retrieval on a fixed toy dataset."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from hybrid_rag.embeddings import make_embedder  # noqa: E402
from hybrid_rag.ingestion import ingest_document  # noqa: E402
from hybrid_rag.retrieval import bm25_scores, cosine, hybrid_search  # noqa: E402

DATA = ROOT / "data" / "sample_docs"
EVAL_DATASET = ROOT / "examples" / "retrieval_eval.jsonl"


def load_queries() -> list[dict[str, str]]:
    with EVAL_DATASET.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]



def rank_metrics(ranked_files: list[str], relevant_file: str, k: int = 3) -> tuple[float, float, float]:
    # Retrieval returns chunks, but this starter dataset labels relevance at document level.
    # Collapse repeated chunks from the same document before scoring to avoid duplicate credit.
    unique_files = list(dict.fromkeys(ranked_files))
    positions = [i + 1 for i, filename in enumerate(unique_files) if filename == relevant_file]
    recall = 1.0 if any(position <= k for position in positions) else 0.0
    reciprocal_rank = 1.0 / positions[0] if positions else 0.0
    dcg = sum(1.0 / __import__("math").log2(position + 1) for position in positions if position <= k)
    ndcg = dcg  # ideal DCG is 1.0 for this single relevant-document judgment
    return recall, reciprocal_rank, ndcg


def main() -> None:
    queries = load_queries()
    backend = __import__("os").getenv("RAG_EMBEDDING_BACKEND", "hashing")
    model = __import__("os").getenv("RAG_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    embedder = make_embedder(backend, model)
    chunks = []
    for path in sorted(DATA.iterdir()):
        if path.suffix.lower() in {".md", ".txt", ".pdf"}:
            _, doc_chunks = ingest_document(path.name, path.read_bytes(), embedder, 900, 150)
            chunks.extend(doc_chunks)
    if not chunks:
        raise SystemExit(f"No supported documents found in {DATA}")

    configs: dict[str, list[tuple[float, float, float]]] = {"bm25-only": [], "dense-only": [], "hybrid-rrf": []}
    for example in queries:
        query = example["query"]
        lexical = bm25_scores(query, chunks)
        query_vector = embedder.encode([query])[0]
        dense = [cosine(query_vector, chunk.embedding) for chunk in chunks]
        rankings = {
            "bm25-only": sorted(range(len(chunks)), key=lambda i: lexical[i], reverse=True),
            "dense-only": sorted(range(len(chunks)), key=lambda i: dense[i], reverse=True),
            "hybrid-rrf": [chunks.index(hit.chunk) for hit in hybrid_search(query, chunks, embedder, len(chunks), 60)],
        }
        for name, ranking in rankings.items():
            filenames = [chunks[index].filename for index in ranking]
            configs[name].append(rank_metrics(filenames, str(example["relevant"])))

    print(f"Dataset: {len(queries)} queries, {len({chunk.filename for chunk in chunks})} documents, {len(chunks)} chunks, relevance judged at document level")
    print("Metric definitions: Recall@3 = any relevant document in top 3; MRR = first relevant rank; nDCG@3 = binary document relevance.")
    print("These are smoke-test metrics on a tiny synthetic set, not generalizable benchmark claims.\n")
    print(f"{'Configuration':<16} {'Recall@3':>10} {'MRR':>10} {'nDCG@3':>10}")
    for name, values in configs.items():
        means = [sum(row[column] for row in values) / len(values) for column in range(3)]
        print(f"{name:<16} {means[0]:>10.3f} {means[1]:>10.3f} {means[2]:>10.3f}")


if __name__ == "__main__":
    main()
