# Hybrid Search RAG

A local-first document question-answering service that ingests PDF, Markdown, and TXT files, combines BM25 keyword retrieval with dense-vector retrieval using reciprocal-rank fusion (RRF), and returns extractive answers with source citations.

> **Current scope:** the first implementation is a transparent retrieval and extractive-answering system, not a generative LLM application. Its default offline hashing embeddings are deterministic lexical features, not semantic language embeddings. Install the optional `semantic` extra and configure a Sentence Transformers model to experiment with genuine semantic embeddings. OCR, hosted vector databases, and generated answers are not yet implemented.

## Problem and intended users

Users often need to find specific facts across a small collection of internal or public documents. This project demonstrates ingestion, chunking, hybrid retrieval, source traceability, API design, and retrieval evaluation without requiring a hosted service or API key.

## Features

- PDF text extraction with page metadata; Markdown and UTF-8 TXT ingestion.
- Overlapping text chunks with deterministic IDs and stored embedding vectors.
- BM25 lexical retrieval, vector cosine similarity, and reciprocal-rank fusion.
- SQLite persistence and document replacement/deletion.
- FastAPI endpoints and a minimal browser UI.
- Extractive answers with citations and explicit abstention when no supporting sentence is found.
- Offline deterministic embedding backend; optional Sentence Transformers backend.
- Unit/API tests and a retrieval evaluation script.

### Non-goals in this version

OCR for scanned PDFs, LLM-generated answers, multi-tenant authorization, distributed vector search, production authentication, and hosted deployment. The API is intended for local development and should not be exposed publicly without additional security controls.

## Architecture

```mermaid
flowchart TD
    U[Browser / CLI / API client] --> API[FastAPI]
    API --> S[Application service]
    S --> I[Document extraction and chunking]
    I --> E[Embedding backend]
    I --> DB[(SQLite: documents, chunks, vectors)]
    S --> R[BM25 + cosine retrieval]
    DB --> R
    R --> F[Reciprocal-rank fusion]
    F --> A[Extractive answer + citations]
    A --> API
    API --> U
```

## Technology choices

- **FastAPI + Pydantic:** typed HTTP contracts and generated OpenAPI docs.
- **SQLite:** persistent local storage with no database server to configure.
- **BM25 implemented in the repository:** transparent lexical baseline without a separate retrieval dependency.
- **NumPy:** cosine similarity calculations.
- **HashingEmbedder:** deterministic, offline lexical-feature vectors for tests and demos. This is not a semantic embedding model.
- **Sentence Transformers (optional):** semantic embedding experiments using `all-MiniLM-L6-v2` by default; the first model run may download model files.
- **pypdf:** PDF text extraction and page references.

## Prerequisites and setup

Python 3.11 or newer is required. From the repository root:

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e '.[dev]'
cp .env.example .env  # optional; the application reads environment variables, not the file automatically
```

The application works without API keys. To use semantic embeddings, install `python -m pip install -e '.[dev,semantic]'` and set `RAG_EMBEDDING_BACKEND=sentence-transformers`. For a persistent shell session, export variables from `.env` using your shell's environment-loading mechanism; never commit real secrets.

## Run locally

Start the API and browser UI:

```bash
hybrid-rag serve
# alternatively: uvicorn hybrid_rag.api:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. API documentation is available at `http://127.0.0.1:8000/docs`.

Index a document with curl (request body is the raw file bytes):

```bash
curl -X POST 'http://127.0.0.1:8000/documents?filename=engineering_handbook.md' \
  --data-binary @data/sample_docs/engineering_handbook.md
```

Ask a question:

```bash
curl -X POST 'http://127.0.0.1:8000/query' \
  -H 'Content-Type: application/json' \
  -d '{"question":"What is the incident acknowledgement target?","top_k":5}'
```

Other endpoints:

- `GET /health` — liveness and configured embedding backend.
- `GET /documents` — indexed document metadata.
- `POST /documents?filename=...` — index a PDF, Markdown, or TXT file (max 10 MiB).
- `DELETE /documents/{document_id}` — delete a document and its chunks.
- `POST /query` — hybrid retrieval and evidence-based extractive answer.

## Configuration

Configuration is read from process environment variables:

| Variable | Default | Meaning |
|---|---|---|
| `RAG_DB_PATH` | `./data/rag.sqlite3` | SQLite database path |
| `RAG_EMBEDDING_BACKEND` | `hashing` | `hashing` or `sentence-transformers` |
| `RAG_EMBEDDING_MODEL` | `sentence-transformers/all-MiniLM-L6-v2` | Model ID for semantic backend |
| `RAG_CHUNK_SIZE` | `900` | Maximum approximate chunk characters |
| `RAG_CHUNK_OVERLAP` | `150` | Overlap between chunks |
| `RAG_TOP_K` | `5` | Default retrieved chunk count |
| `RAG_RRF_K` | `60` | RRF rank smoothing constant |

## Evaluation

A versioned labeled retrieval set (`examples/retrieval_eval.jsonl`) and evaluator (`scripts/evaluate_retrieval.py`) are included. Metrics include Recall@k, reciprocal rank, and nDCG@k. Run the evaluation after installing development dependencies:

```bash
python scripts/evaluate_retrieval.py
```

The script reports BM25-only, dense-only, and hybrid retrieval on the same fixed synthetic corpus. A local run in the implementation environment on 6 queries and 4 synthetic documents produced:

| Configuration | Recall@3 | MRR | nDCG@3 |
|---|---:|---:|---:|
| BM25-only | 1.000 | 0.917 | 0.938 |
| Dense-only (offline hashing vectors) | 1.000 | 0.917 | 0.938 |
| Hybrid RRF | 1.000 | 0.917 | 0.938 |

These are actual smoke-test results, not a meaningful general benchmark: the corpus is tiny, labels are at document level, and the hashing vectors are lexical. Equal metrics do not demonstrate that hybrid retrieval improves quality. Rerun the script after changes and build a larger, independently held-out labeled dataset before drawing conclusions. Do not tune against a held-out test set.

Answer-quality evaluation (correctness, groundedness, and citation support) remains a follow-up milestone; the current extractive response design reduces generation hallucinations but can still miss relevant sentences or abstain on paraphrased questions.

## Testing and quality checks

```bash
pytest
ruff check src tests scripts
```

CI runs unit and API tests on supported Python versions. Add measured coverage and integration results here after running them; no test or benchmark status is claimed in advance.

## Docker

```bash
docker compose up --build
```

The compose file mounts `./data` for SQLite persistence and binds the service to localhost. Do not expose the unauthenticated development API to an untrusted network.

## Security, privacy, and limitations

- Do not upload confidential employer, DRDO, customer, or personal data.
- The demo has no authentication or tenant isolation; use only in a trusted local environment.
- Upload size and filename are validated, but production deployments need authentication, rate limiting, stronger request controls, and operational monitoring.
- PDF extraction does not run OCR; image-only PDFs are rejected with an explicit error.
- Indexed documents are treated as untrusted content. There is no LLM tool execution in this version, and no prompt is executed from document text.
- Hashing vectors are lexical and collision-prone; use the optional semantic backend for semantic retrieval experiments.
- Extractive answers may be incomplete. Verify cited passages before relying on an answer.
- The SQLite implementation loads all chunks into memory for each search and is intended for small corpora.

## Deployment

Docker supports a reproducible local demonstration. Before a public deployment, implement authentication, per-user authorization, request rate limiting, privacy-aware retention, stronger resource controls, and production observability. Deployment to a cloud platform is not yet verified.

## Personal engineering contributions

Use this section to record what you personally implemented, tested, evaluated, and deployed. Do not claim a feature, metric, or deployment until you have verified it yourself.

## Future improvements

1. Add reranking and compare against the fixed evaluation set.
2. Calibrate abstention with answerable and unanswerable questions.
3. Add answer groundedness and citation-support evaluation.
4. Add OCR and table extraction for scanned or complex PDFs.
5. Add authentication, rate limits, and per-tenant document access.
6. Evaluate Qdrant or pgvector only when corpus size or filtering requirements justify it.

## Publish to GitHub

Create an empty repository on GitHub named `hybrid-search-rag` (do not pre-create a README or license), then run from this directory:

```bash
git init
git add .
git commit -m "Build initial hybrid search RAG application"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hybrid-search-rag.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username. Review `git status` and inspect staged files before committing; never commit `.env`, private documents, local databases, or confidential employer data.
